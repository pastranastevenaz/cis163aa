import javax.swing.JOptionPane;
/**
* <h1>Burma Shave</h1>
* <p>This program outputs 4 lines of a Burma Shave advertisement to 4 Swing dialog boxes.</p>
* <br>
* STE2253402
* CIS163AA - Java Programming: Level I - Class # 29647
* @author  Steven Pastrana
* @version 1.0
* @since   2017-02-09
*/
public class BurmaShave {
  public static void main(String[] args) {
    JOptionPane.showMessageDialog(null, "No matter how you slice it,");
    JOptionPane.showMessageDialog(null, "it's still your face.");
    JOptionPane.showMessageDialog(null, "Be humane.");
    JOptionPane.showMessageDialog(null, "Use Burma Shave");
  }
}

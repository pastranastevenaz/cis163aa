/**
* <h1>Tables and Chairs</h1>
* <p>This program outputs a set of chairs and a table to the terminal </p>
* <br>
* STE2253402
* CIS163AA - Java Programming: Level I - Class # 29647
* @author  Steven Pastrana
* @version 1.0
* @since   2017-02-09
*/

public class TableAndChairs{
  public static void main(String[] args){
    System.out.println("X                       X");
    System.out.println("X                       X");
    System.out.println("X      XXXXXXXXXXX      X");
    System.out.println("XXXXX  X         X  XXXXX");
    System.out.println("X   X  X         X  X   X");
    System.out.println("X   X  X         X  X   X");
  }
}

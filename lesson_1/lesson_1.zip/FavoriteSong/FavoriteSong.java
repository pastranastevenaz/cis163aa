/**
* <h1>Favorite Song</h1>
* <p>This program outputs 4 lines of the song "Developers (feat. Steve Balmer)" by Smixx </p>
* <br>
* STE2253402
* CIS163AA - Java Programming: Level I - Class # 29647
* @author  Steven Pastrana
* @version 1.0
* @since   2017-02-09
*/
public class FavoriteSong {
  public static void main(String [] args) {
    System.out.println("I’m a developer in many senses of the word, cause I make these applications, but I also use these verbs.");
    System.out.println("To make this music, I construct it line by line. Just like when I’m coding, another software design.");
    System.out.println("In both cases its about design patterns. Anyone can get the job done, its the execution that matters.");
    System.out.println("I have many interests. Sometimes they conflict. My creativity can usually be a benefit.");
  }
}

/**
* <h1>HelloApp</h1>
* <p>The Hello App Class includes the main method of the class. It instantiates a new instance of the
* HelloFrame class, and sets its isibility to true</p>
* <br>
* STE2253402
* CIS163AA - Java Programming: Level I - Class # 29647
* @author  Steven Pastrana
* @version 1.0
* @since   2017-03-30
*/

public class HelloApp{

  public static void main(String[] args) {
    HelloFrame app = new HelloFrame();
    app.setVisible(true);
  }
}

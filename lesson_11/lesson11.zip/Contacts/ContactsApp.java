/**
* <h1>ContactsApp</h1>
* <p>The ContactsApp Class includes the main method of the class. It instantiates a new instance of the
* ContactsApp class, and sets its visibility to true</p>
* <br>
* STE2253402
* CIS163AA - Java Programming: Level I - Class # 29647
* @author  Steven Pastrana
* @version 1.0
* @since   2017-04-02
*/
public class ContactsApp{
  public static void main(String[] args) {
    ContactsFrame myApp = new ContactsFrame();
    myApp.setVisible(true);
  }
}
